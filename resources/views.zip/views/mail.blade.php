<span> User Name: <strong>{{$name}}</strong> </span>
<br/>
<span> User Email: <strong>{{$email}}</strong> </span>
<br/>
<span> User Subject Name: <strong>{{$subject}}</strong> </span>
<br/>
<span> User Message: <strong>{{$message1}}</strong> </span>

