<?php $__env->startSection('title', 'Wallet '); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-9">
    <div class="dash-content">
        <div class="row no-margin">
            <div class="col-md-12">
                <h4 class="page-title"><?php echo app('translator')->get('user.my_wallet'); ?></h4>
            </div>
        </div>
        <?php echo $__env->make('common.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row no-margin">
            <form action="<?php echo e(url('add/money')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

                <div class="col-md-6">
                     
                    <div class="wallet">
                        <h4 class="amount">
                        	<span class="price"><?php echo e(currency(Auth::user()->wallet_balance)); ?></span>
                        	<span class="txt"><?php echo app('translator')->get('user.in_your_wallet'); ?></span>
                        </h4>
                    </div>                                                               

                </div>
                <?php if(Setting::get('CARD') == 1): ?>
                <div class="col-md-6">
                    
                    <h6><strong><?php echo app('translator')->get('user.add_money'); ?></strong></h6>

                    <div class="input-group full-input">
                        <input type="number" class="form-control" name="amount" placeholder="Enter Amount" >
                    </div>
                    <br>
                    <?php if($cards->count() > 0): ?>
                        <select class="form-control" name="card_id">
	                      <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                        <option <?php if($card->is_default == 1): ?> selected <?php endif; ?> value="<?php echo e($card->card_id); ?>"><?php echo e($card->brand); ?> **** **** **** <?php echo e($card->last_four); ?></option>
	                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                    <?php else: ?>
                    	<p>Please <a href="<?php echo e(url('payment')); ?>">add card</a> to continue</p>
                    <?php endif; ?>
                    
                    <button type="submit" class="full-primary-btn fare-btn"><?php echo app('translator')->get('user.add_money'); ?></button> 

                </div>
                <?php endif; ?>
            </form>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>