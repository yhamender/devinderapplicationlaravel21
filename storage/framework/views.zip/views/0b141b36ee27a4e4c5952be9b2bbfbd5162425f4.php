<?php $__env->startSection('title', $page); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-area py-1">
        <div class="container-fluid">
            <div class="box box-block bg-white">
            	<h3><?php echo e($page); ?></h3>

            	<div class="row">

						<div class="row row-md mb-2" style="padding: 15px;">
							<div class="col-md-12">
									<div class="box bg-white">
										<div class="box-block clearfix">
											<h5 class="float-xs-left">Earnings</h5>
											<div class="float-xs-right">
											</div>
										</div>

										<?php if(count($Providers) != 0): ?>
								            <table class="table table-striped table-bordered dataTable" id="table-2">
								                <thead>
								                   <tr>
														<td>Driver Name</td>
														<td>Mobile</td>
														<td>Status</td>
														<td>Total Rides</td>
														<td>Total Earning</td>
														<td>Commission</td>
														<td>Joined at</td>
														<td>Details</td>
													</tr>
								                </thead>
								                <tbody>
								                <?php $diff = ['-success','-info','-warning','-danger']; ?>
														<?php $__currentLoopData = $Providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $provider): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
															<tr>
																<td>
																	<?php echo e($provider->first_name); ?> 
																	<?php echo e($provider->last_name); ?>

																</td>
																<td>
																	<?php echo e($provider->mobile); ?>

																</td>
																<td>
																	<?php if($provider->status == "approved"): ?>
																		<span class="tag tag-success"><?php echo e($provider->status); ?></span>
																	<?php elseif($provider->status == "banned"): ?>
																		<span class="tag tag-danger"><?php echo e($provider->status); ?></span>
																	<?php else: ?>
																		<span class="tag tag-info"><?php echo e($provider->status); ?></span>
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($provider->rides_count): ?>
																		<?php echo e($provider->rides_count); ?>

																	<?php else: ?>
																	 	-
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($provider->payment): ?>
																		<?php echo e(currency($provider->payment[0]->overall)); ?>

																	<?php else: ?>
																	 	-
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($provider->payment): ?>
																		<?php echo e(currency($provider->payment[0]->commission)); ?>

																	<?php else: ?>
																	 	-
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($provider->created_at): ?>
																		<span class="text-muted"><?php echo e($provider->created_at->diffForHumans()); ?></span>
																	<?php else: ?>
																	 	-
																	<?php endif; ?>
																</td>
																<td>
																	<a href="<?php echo e(route('admin.provider.statement', $provider->id)); ?>">View by Ride</a>
																</td>
															</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
															
								                <tfoot>
								                    <tr>
														<td>Driver Name</td>
														<td>Mobile</td>
														<td>Status</td>
														<td>Total Rides</td>
														<td>Total Earning</td>
														<td>Commission</td>
														<td>Joined at</td>
														<td>Details</td>
													</tr>
								                </tfoot>
								            </table>
								            <?php else: ?>
								            <h6 class="no-result">No results found</h6>
								            <?php endif; ?> 

									</div>
								</div>

							</div>

            	</div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>