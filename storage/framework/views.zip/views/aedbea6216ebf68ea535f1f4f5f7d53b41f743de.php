<?php $__env->startSection('title', 'Providers '); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
            <h5 class="mb-1">
                Providers
                <?php if(Setting::get('demo_mode', 0) == 1): ?>
                <span class="pull-right">(*personal information hidden in demo)</span>
                <?php endif; ?>
            </h5>
            <a href="<?php echo e(route('admin.provider.create')); ?>" style="margin-left: 1em;" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Add New Provider</a>
            <table class="table table-striped table-bordered dataTable" id="table-2">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Total Requests</th>
                        <th>Accepted Requests</th>
                        <th>Cancelled Requests</th>
                        <th>Documents / Service Type</th>
                        <th>Online</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $provider): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($provider->first_name); ?> <?php echo e($provider->last_name); ?></td>
                        <?php if(Setting::get('demo_mode', 0) == 1): ?>
                        <td><?php echo e(substr($provider->email, 0, 3).'****'.substr($provider->email, strpos($provider->email, "@"))); ?></td>
                        <?php else: ?>
                        <td><?php echo e($provider->email); ?></td>
                        <?php endif; ?>
                        <?php if(Setting::get('demo_mode', 0) == 1): ?>
                        <td>+919876543210</td>
                        <?php else: ?>
                        <td><?php echo e($provider->mobile); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($provider->total_requests); ?></td>
                        <td><?php echo e($provider->accepted_requests); ?></td>
                        <td><?php echo e($provider->total_requests - $provider->accepted_requests); ?></td>
                        <td>
                            <?php if($provider->pending_documents() > 0 || $provider->service == null): ?>
                                <a class="btn btn-danger btn-block label-right" href="<?php echo e(route('admin.provider.document.index', $provider->id )); ?>">Attention! <span class="btn-label"><?php echo e($provider->pending_documents()); ?></span></a>
                            <?php else: ?>
                                <a class="btn btn-success btn-block" href="<?php echo e(route('admin.provider.document.index', $provider->id )); ?>">All Set!</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($provider->service): ?>
                                <?php if($provider->service->status == 'active'): ?>
                                    <label class="btn btn-block btn-primary">Yes</label>
                                <?php else: ?>
                                    <label class="btn btn-block btn-warning">No</label>
                                <?php endif; ?>
                            <?php else: ?>
                                <label class="btn btn-block btn-danger">N/A</label>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="input-group-btn">
                                <?php if($provider->status == 'approved'): ?>
                                <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.provider.disapprove', $provider->id )); ?>">Disable</a>
                                <?php else: ?>
                                <a class="btn btn-success btn-block" href="<?php echo e(route('admin.provider.approve', $provider->id )); ?>">Enable</a>
                                <?php endif; ?>
                                <button type="button" 
                                    class="btn btn-info btn-block dropdown-toggle"
                                    data-toggle="dropdown">Action
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('admin.provider.request', $provider->id)); ?>" class="btn btn-default"><i class="fa fa-search"></i> History</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('admin.provider.statement', $provider->id)); ?>" class="btn btn-default"><i class="fa fa-account"></i> Statements</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('admin.provider.edit', $provider->id)); ?>" class="btn btn-default"><i class="fa fa-pencil"></i> Edit</a>
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('admin.provider.destroy', $provider->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE">
                                            <button class="btn btn-default look-a-like" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i> Delete</button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Total Requests</th>
                        <th>Accepted Requests</th>
                        <th>Cancelled Requests</th>
                        <th>Documents / Service Type</th>
                        <th>Online</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>