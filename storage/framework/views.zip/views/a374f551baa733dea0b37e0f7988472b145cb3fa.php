<?php $__env->startSection('title', 'Request History '); ?>

<?php $__env->startSection('content'); ?>

<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
            <h5 class="mb-1">Request History</h5>
            <?php if(count($requests) != 0): ?>
            <table class="table table-striped table-bordered dataTable" id="table-2">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Booking ID</th>
                        <th>User Name</th>
                        <th>Provider Name</th>
                        <th>Date &amp; Time</th>
                        <th>Status</th>
                        <th>Amount</th>
                        <th>Payment Mode</th>
                        <th>Payment Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($request->id); ?></td>
                        <td><?php echo e($request->booking_id); ?></td>
                        <td>
                            <?php if($request->provider): ?>
                                <?php echo e($request->user->first_name); ?> <?php echo e($request->user->last_name); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($request->provider): ?>
                                <?php echo e($request->provider->first_name); ?> <?php echo e($request->provider->last_name); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($request->created_at): ?>
                                <span class="text-muted"><?php echo e($request->created_at->diffForHumans()); ?></span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($request->status); ?></td>
                        <td>
                            <?php if($request->payment != ""): ?>
                                <?php echo e(currency($request->payment->total)); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($request->payment_mode); ?></td>
                        <td>
                            <?php if($request->paid): ?>
                                Paid
                            <?php else: ?>
                                Not Paid
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-primary waves-effect dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    Action
                                </button>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(route('admin.requests.show', $request->id)); ?>" class="dropdown-item">
                                        <i class="fa fa-search"></i> More Details
                                    </a>
                                    <form action="<?php echo e(route('admin.requests.destroy', $request->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="dropdown-item">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                         <th>#</th>
                        <th>Booking ID</th>
                        <th>User Name</th>
                        <th>Provider Name</th>
                        <th>Date &amp; Time</th>
                        <th>Status</th>
                        <th>Amount</th>
                        <th>Payment Mode</th>
                        <th>Payment Status</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
            <?php else: ?>
            <h6 class="no-result">No results found</h6>
            <?php endif; ?> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>