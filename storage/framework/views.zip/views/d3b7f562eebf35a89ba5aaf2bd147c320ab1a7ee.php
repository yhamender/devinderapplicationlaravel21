

<?php $__env->startSection('title', 'Update Service Type '); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
            <a href="<?php echo e(route('admin.service.index')); ?>" class="btn btn-default pull-right"><i class="fa fa-angle-left"></i> Back</a>

            <h5 style="margin-bottom: 2em;">Update User</h5>

            <form class="form-horizontal" action="<?php echo e(route('admin.service.update', $service->id )); ?>" method="POST" enctype="multipart/form-data" role="form">
                <?php echo e(csrf_field()); ?>

				


                <input type="hidden" name="_method" value="PATCH">
                <div class="form-group row">
                    <label for="name" class="col-xs-2 col-form-label">Service Name</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->name); ?>" name="name" required id="name" placeholder="Service Name">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="provider_name" class="col-xs-2 col-form-label">Provider Name</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->provider_name); ?>" name="provider_name" required id="provider_name" placeholder="Provider Name">
                    </div>
                </div>

                <div class="form-group row">
                    
                    <label for="image" class="col-xs-2 col-form-label">Picture</label>
                    <div class="col-xs-10">
                        <?php if(isset($service->image)): ?>
                        <img style="height: 90px; margin-bottom: 15px; border-radius:2em;" src="<?php echo e($service->image); ?>">
                        <?php endif; ?>
                        <input type="file" accept="image/*" name="image" class="dropify form-control-file" id="image" aria-describedby="fileHelp">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="fixed" class="col-xs-2 col-form-label">Base Price (<?php echo e(currency('')); ?>)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->fixed); ?>" name="fixed" required id="fixed" placeholder="Base Price">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="distance" class="col-xs-2 col-form-label">Base Distance (0Mile)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->distance); ?>" name="distance" required id="distance" placeholder="Base Distance">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="minute" class="col-xs-2 col-form-label">Unit Time Pricing  (<?php echo e(currency()); ?>)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->minute); ?>" name="minute" required id="minute" placeholder="Unit Time Pricing">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="price" class="col-xs-2 col-form-label">Unit Distance Price (Miles)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e($service->price/0.6); ?>" name="price" required id="price" placeholder="Unit Distance Price">
                    </div>
                </div>

                 <div class="form-group row">
                    <label for="capacity" class="col-xs-2 col-form-label">Seat Capacity</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="number" value="<?php echo e($service->capacity); ?>" name="capacity" required id="capacity" placeholder="Seat Capacity">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="calculator" class="col-xs-2 col-form-label">Pricing Logic</label>
                    <div class="col-xs-10">
                        <select class="form-control" id="calculator" name="calculator">
                            <option value="MIN" <?php if($service->calculator =='MIN'): ?> selected <?php endif; ?>><?php echo app('translator')->get('servicetypes.MIN'); ?></option>
                            <option value="HOUR" <?php if($service->calculator =='HOUR'): ?> selected <?php endif; ?>><?php echo app('translator')->get('servicetypes.HOUR'); ?></option>
                            <option value="DISTANCE" <?php if($service->calculator =='DISTANCE'): ?> selected <?php endif; ?>><?php echo app('translator')->get('servicetypes.DISTANCE'); ?></option>
                            <option value="DISTANCEMIN" <?php if($service->calculator =='DISTANCEMIN'): ?> selected <?php endif; ?>><?php echo app('translator')->get('servicetypes.DISTANCEMIN'); ?></option>
                            <option value="DISTANCEHOUR" <?php if($service->calculator =='DISTANCEHOUR'): ?> selected <?php endif; ?>><?php echo app('translator')->get('servicetypes.DISTANCEHOUR'); ?></option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <a href="<?php echo e(route('admin.service.index')); ?>" class="btn btn-danger btn-block">Cancel</a>
                    </div>
                    <div class="col-xs-12 col-sm-6 offset-md-6 col-md-3">
                        <button type="submit" class="btn btn-primary btn-block">Update Service Type</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>