<?php $__env->startSection('title', $page); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-area py-1">
        <div class="container-fluid">
            <div class="box box-block bg-white">
            	<h3><?php echo e($page); ?></h3>

            	<div style="text-align: center;padding: 20px;color: blue;font-size: 24px;">
            		<p><strong>
            			<span>Over All Earning : <?php echo e(currency($revenue[0]->overall)); ?></span>
            			<br>
            			<span>Over All Commission : <?php echo e(currency($revenue[0]->commission)); ?></span>
            		</strong></p>
            	</div>

            	<div class="row">

	            	<div class="col-lg-4 col-md-6 col-xs-12">
						<div class="box box-block bg-white tile tile-1 mb-2">
							<div class="t-icon right"><span class="bg-danger"></span><i class="ti-rocket"></i></div>
							<div class="t-content">
								<h6 class="text-uppercase mb-1">Total No. of Rides</h6>
								<h1 class="mb-1"><?php echo e($rides->count()); ?></h1>
								<span class="text-muted font-90">% down from cancelled Request</span>
							</div>
						</div>
					</div>


					<div class="col-lg-4 col-md-6 col-xs-12">
						<div class="box box-block bg-white tile tile-1 mb-2">
							<div class="t-icon right"><span class="bg-success"></span><i class="ti-bar-chart"></i></div>
							<div class="t-content">
								<h6 class="text-uppercase mb-1">Revenue</h6>
								<h1 class="mb-1"><?php echo e(currency($revenue[0]->overall)); ?></h1>
								<i class="fa fa-caret-up text-success mr-0-5"></i><span>from <?php echo e($rides->count()); ?> Rides</span>
							</div>
						</div>
					</div>

					<div class="col-lg-4 col-md-6 col-xs-12">
						<div class="box box-block bg-white tile tile-1 mb-2">
							<div class="t-icon right"><span class="bg-warning"></span><i class="ti-archive"></i></div>
							<div class="t-content">
								<h6 class="text-uppercase mb-1">Cancelled Rides</h6>
								<h1 class="mb-1"><?php echo e($cancel_rides); ?></h1>
								<i class="fa fa-caret-down text-danger mr-0-5"></i><span>for <?php if($cancel_rides == 0): ?> 0.00 <?php else: ?> <?php echo e(round($cancel_rides/$rides->count(),2)); ?>% <?php endif; ?> Rides</span>
							</div>
						</div>
					</div>

						<div class="row row-md mb-2" style="padding: 15px;">
							<div class="col-md-12">
									<div class="box bg-white">
										<div class="box-block clearfix">
											<h5 class="float-xs-left">Earnings</h5>
											<div class="float-xs-right">
											</div>
										</div>

										<?php if(count($rides) != 0): ?>
								            <table class="table table-striped table-bordered dataTable" id="table-2">
								                <thead>
								                   <tr>
														<td>Booking ID</td>
														<td>Picked up</td>
														<td>Dropped</td>
														<td>Request Details</td>
														<td>Commission</td>
														<td>Dated on</td>
														<td>Status</td>
														<td>Earned</td>
													</tr>
								                </thead>
								                <tbody>
								                <?php $diff = ['-success','-info','-warning','-danger']; ?>
														<?php $__currentLoopData = $rides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ride): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
															<tr>
																<td><?php echo e($ride->booking_id); ?></td>
																<td>
																	<?php if($ride->s_address != ''): ?>
																		<?php echo e($ride->s_address); ?>

																	<?php else: ?>
																		Not Provided
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($ride->d_address != ''): ?>
																		<?php echo e($ride->d_address); ?>

																	<?php else: ?>
																		Not Provided
																	<?php endif; ?>
																</td>
																<td>
																	<?php if($ride->status != "CANCELLED"): ?>
																		<a class="text-primary" href="<?php echo e(route('admin.requests.show',$ride->id)); ?>"><span class="underline">View Ride Details</span></a>
																	<?php else: ?>
																		<span>No Details Found </span>
																	<?php endif; ?>									
																</td>
																<td><?php echo e(currency($ride->payment['commision'])); ?></td>
																<td>
																	<span class="text-muted"><?php echo e(date('d M Y',strtotime($ride->created_at))); ?></span>
																</td>
																<td>
																	<?php if($ride->status == "COMPLETED"): ?>
																		<span class="tag tag-success"><?php echo e($ride->status); ?></span>
																	<?php elseif($ride->status == "CANCELLED"): ?>
																		<span class="tag tag-danger"><?php echo e($ride->status); ?></span>
																	<?php else: ?>
																		<span class="tag tag-info"><?php echo e($ride->status); ?></span>
																	<?php endif; ?>
																</td>
																<td><?php echo e(currency($ride->payment['fixed'] + $ride->payment['distance'])); ?></td>

															</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
															
								                <tfoot>
								                    <tr>
														<td>Booking ID</td>
														<td>Picked up</td>
														<td>Dropped</td>
														<td>Request Details</td>
														<td>Commission</td>
														<td>Dated on</td>
														<td>Status</td>
														<td>Earned</td>
													</tr>
								                </tfoot>
								            </table>
								            <?php else: ?>
								            <h6 class="no-result">No results found</h6>
								            <?php endif; ?> 

									</div>
								</div>

							</div>

            	</div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>